// Select all buttons with the scroll-link class
const scrollLinks = document.querySelectorAll('.scroll-link');

// Add an event listener to each button
scrollLinks.forEach((link) => {
  link.addEventListener('click', (e) => {
    // Only prevent default for direct clicks on links, not their children
    if (e.target === link || e.target.tagName === 'BUTTON') {
      e.preventDefault();
      const targetId = link.getAttribute('href').split('#')[1];
      const targetSection = document.getElementById(targetId);
      const rect = targetSection.getBoundingClientRect();
      const scrollToPosition = window.scrollY + rect.top + (rect.height / 2) - (window.innerHeight / 2);
      window.scrollTo({ top: scrollToPosition, behavior: 'smooth' });
    }
  });
});

document.addEventListener('DOMContentLoaded', function() {
    // For touch devices, we need a click handler as hover doesn't work well
    if ('ontouchstart' in window) {
        const menuItems = document.querySelectorAll('.menu-item');
        
        menuItems.forEach(item => {
            const button = item.querySelector('button');
            const dropdown = item.querySelector('.dropdown');
            
            if (button && dropdown) {
                button.addEventListener('click', function(e) {
                    // Toggle current dropdown
                    const isOpen = dropdown.style.display === 'block';
                    
                    // Close all other dropdowns first
                    document.querySelectorAll('.dropdown').forEach(d => {
                        d.style.display = 'none';
                    });
                    
                    // Toggle this dropdown
                    dropdown.style.display = isOpen ? 'none' : 'block';
                    
                    // Don't prevent default so scrolling still works when dropdown is closed
                    if (isOpen) {
                        return;
                    }
                    
                    // Prevent default only when opening dropdown
                    e.preventDefault();
                    e.stopPropagation();
                });
            }
        });
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', function(e) {
            const isClickInsideDropdown = Array.from(menuItems).some(item => item.contains(e.target));
            
            if (!isClickInsideDropdown) {
                document.querySelectorAll('.dropdown').forEach(dropdown => {
                    dropdown.style.display = 'none';
                });
            }
        });
    }
});

// Initialize Swiper with settings to show 3 slides at once
new Swiper('.card-wrapper', {
    // Show 3 slides at a time
    slidesPerView: 3,
    spaceBetween: 30,
    
    // Enable loop
    loop: true,
    
    // Center the active slide
    centeredSlides: false,
    
    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
        dynamicBullets: true
    },
    
    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    
    // Auto play (optional)
    autoplay: {
        delay: 4000,
        disableOnInteraction: false,
    },
});

// Add input event listeners for real-time ALL CAPS conversion
document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('user-name');
    const messageInput = document.getElementById('message');
    
    // Convert name input to ALL CAPS
    if (nameInput) {
        nameInput.addEventListener('input', function(e) {
            const cursorPosition = e.target.selectionStart;
            const uppercaseValue = e.target.value.toUpperCase();
            e.target.value = uppercaseValue;
            
            // Restore cursor position
            e.target.setSelectionRange(cursorPosition, cursorPosition);
        });
    }
    
    // Convert message input to ALL CAPS
    if (messageInput) {
        messageInput.addEventListener('input', function(e) {
            const cursorPosition = e.target.selectionStart;
            const uppercaseValue = e.target.value.toUpperCase();
            e.target.value = uppercaseValue;
            
            // Restore cursor position
            e.target.setSelectionRange(cursorPosition, cursorPosition);
        });
    }
});

// Google Sheets Form Submission
const scriptURL = 'https://script.google.com/macros/s/AKfycbyMsInJ2BW_YlHCT7-NwamBp1WjQFUpd_gYoXkvs5qTMpL748PqyiAsEy-2GD8Zt2SU/exec';
const form = document.forms['feedback-form'];

form.addEventListener('submit', e => {
    e.preventDefault();
    
    // Show loading state
    const submitBtn = document.getElementById('submit');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Sending...';
    submitBtn.disabled = true;
    
    // Create FormData from form
    const formData = new FormData(form);
    
    // Send data to Google Apps Script
    fetch(scriptURL, { 
        method: 'POST', 
        body: formData,
        mode: 'no-cors' // This is important for Google Apps Script
    })
    .then(response => {
    // Reset button state
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
    
    // Show success modal
    showSuccessModal();
    
    // Reset form
    form.reset();
    })
    .catch(error => {
        console.error('Error!', error.message);
        
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        // Show error message
        alert("Sorry, there was an error sending your message. Please try again.");
    });
});

// Success Modal Functions
function showSuccessModal() {
    document.getElementById('success-modal').style.display = 'block';
}

function closeSuccessModal() {
    document.getElementById('success-modal').style.display = 'none';
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('success-modal');
    if (e.target === modal) {
        closeSuccessModal();
    }
});

// Dev Modal Functions
function showDevModal() {
    document.getElementById('dev-modal').style.display = 'block';
}

function closeDevModal() {
    document.getElementById('dev-modal').style.display = 'none';
}

// Add event listener for dev info button
document.addEventListener('DOMContentLoaded', function() {
    const devButton = document.querySelector('.devinfo');
    if (devButton) {
        devButton.addEventListener('click', showDevModal);
    }
    
    // Close dev modal when clicking outside
    document.addEventListener('click', function(e) {
        const devModal = document.getElementById('dev-modal');
        if (e.target === devModal) {
            closeDevModal();
        }
    });
});