// Wait for the DOM to fully load
document.addEventListener('DOMContentLoaded', function() {
    // Auto-generate school year based on current date
    function setSchoolYear() {
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        
        // School year is always current year to next year
        // Example: 2025 - 2026, 2026 - 2027, etc.
        const schoolYearStart = currentYear;
        const schoolYearEnd = currentYear + 1;
        
        const schoolYear = `${schoolYearStart} - ${schoolYearEnd}`;
        
        // Set the school year in the input field
        const schoolYearInput = document.querySelector('.input7');
        if (schoolYearInput) {
            schoolYearInput.value = schoolYear;
        }
        
        return schoolYear;
    }
    
    // Set the school year when page loads
    setSchoolYear();
    
    // Get references to the dropdowns
    const enrolleeTypeDropdown = document.getElementById('selection1');
    const courseStrandDropdown = document.getElementById('selection3');
    
    // Store the original SHS and College options for later use
    const shsOptions = [];
    const collegeOptions = [];
    
    // Collect and store all the options from the second dropdown
    for (let i = 0; i < courseStrandDropdown.options.length; i++) {
        const option = courseStrandDropdown.options[i];
        
        if (option.id === 'shsvalue') {
            shsOptions.push({
                value: option.value,
                text: option.text,
                id: option.id
            });
        } else if (option.id === 'collegevalue') {
            collegeOptions.push({
                value: option.value,
                text: option.text,
                id: option.id
            });
        }
    }
    
    // Add CSS for transitions
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-5px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .option-animation {
            animation: fadeIn 0.3s ease-in-out forwards;
        }
        
        #selection3 option {
            transition: opacity 0.3s ease;
        }
    `;
    document.head.appendChild(style);
    
    // Function to update the second dropdown based on the selection in the first one
    function updateCourseOptions() {
        // Get the selected value from the first dropdown
        const selectedValue = enrolleeTypeDropdown.value;
        
        // Clear all options except the first one (placeholder)
        while (courseStrandDropdown.options.length > 1) {
            courseStrandDropdown.remove(1);
        }
        
        // Reset to placeholder
        courseStrandDropdown.selectedIndex = 0;
        
        // Add appropriate options based on selection
        if (selectedValue === 'Grade 11' || selectedValue === 'Grade 12') {
            // Add SHS options with delay for animation effect
            shsOptions.forEach(function(optionData, index) {
                setTimeout(() => {
                    const option = document.createElement('option');
                    option.value = optionData.value;
                    option.text = optionData.text;
                    option.id = optionData.id;
                    option.classList.add('option-animation');
                    courseStrandDropdown.add(option);
                }, index * 50); // Stagger the appearance by 50ms each
            });
        } else if (selectedValue === 'First Year' || selectedValue === 'Second Year' || selectedValue === 'Third Year' || selectedValue === 'Fourth Year') {
            // Add College options with delay for animation effect
            collegeOptions.forEach(function(optionData, index) {
                setTimeout(() => {
                    const option = document.createElement('option');
                    option.value = optionData.value;
                    option.text = optionData.text;
                    option.id = optionData.id;
                    option.classList.add('option-animation');
                    courseStrandDropdown.add(option);
                }, index * 50); // Stagger the appearance by 50ms each
            });
        }
    }
    
    // Function to handle dropdown opening animation
    function enhanceDropdownExperience() {
        const selects = document.querySelectorAll('select');
        
        selects.forEach(select => {
            // Add transition effect to the select element
            select.style.transition = 'all 0.3s ease';
            
            // Add focus and blur events for subtle highlight effect
            select.addEventListener('focus', function() {
                this.style.boxShadow = '0 0 5px rgba(255, 187, 0, 0.7)';
                this.style.borderColor = '#FFBB00';
            });
            
            select.addEventListener('blur', function() {
                this.style.boxShadow = 'none';
                this.style.borderColor = '#000';
            });
        });
    }
    
    // Add event listener to the enrollee type dropdown
    enrolleeTypeDropdown.addEventListener('change', updateCourseOptions);
    
    // Initialize the course dropdown (it will be empty except placeholder at first)
    updateCourseOptions();
    
    // Apply enhanced dropdown experience
    enhanceDropdownExperience();
});

// Google Sheets Form Submission for Enrollment Form
const scriptURL = 'https://script.google.com/macros/s/AKfycbyW0zQSdmo7ZvI0H5StxEutJVRDNcFKJhAOfjpE3aUdot68NSISYKvIJ9d0zTBVXQb2/exec'; // Replace with your Google Apps Script URL
const form = document.forms['enrollment-form'];

form.addEventListener('submit', e => {
    e.preventDefault();
    
    // Check if checkbox is checked
    const checkbox = document.getElementById('agreement-checkbox');
    if (!checkbox.checked) {
        checkbox.style.outline = '2px solid red';
        setTimeout(() => {
            checkbox.style.outline = 'none';
        }, 1000);
        return;
    }
    
    // Show loading state
    const submitBtn = document.querySelector('.submit');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Submitting...';
    submitBtn.disabled = true;
    
    // Create FormData from form
    const formData = new FormData(form);

    const dropdownFields = ['EnrolleeType', 'EnrolleeStatus', 'PreferredCourse', 'Semester'];

    dropdownFields.forEach(fieldName => {
        const fieldValue = formData.get(fieldName);
        if (fieldValue) {
            formData.set(fieldName, fieldValue.toUpperCase());
        }
    });
    
    // Manually add the school year value since it's readonly
    const schoolYearInput = document.querySelector('.input7');
    if (schoolYearInput) {
        formData.append('SchoolYear', schoolYearInput.value);
    }
    
    // Add timestamp
    formData.append('Timestamp', new Date().toLocaleString());
    
    // Send data to Google Apps Script
    fetch(scriptURL, { 
        method: 'POST', 
        body: formData,
        mode: 'no-cors' // This is important for Google Apps Script
    })
    .then(response => {
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        // Show success modal
        showSuccessModal();
        
        // Reset form
        form.reset();
        
        // Reset school year after form reset
        setTimeout(() => {
            const currentDate = new Date();
            const currentYear = currentDate.getFullYear();
            
            // School year is always current year to next year
            const schoolYear = `${currentYear} - ${currentYear + 1}`;
            const schoolYearInput = document.querySelector('.input7');
            if (schoolYearInput) {
                schoolYearInput.value = schoolYear;
            }
        }, 100);
        
        // Reset course dropdown to initial state
        const courseStrandDropdown = document.getElementById('selection3');
        while (courseStrandDropdown.options.length > 1) {
            courseStrandDropdown.remove(1);
        }
        courseStrandDropdown.selectedIndex = 0;
    })
    .catch(error => {
        console.error('Error!', error.message);
        
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        // Show error message
        alert("Sorry, there was an error submitting your enrollment form. Please try again.");
    });
});

// Success Modal Functions
function showSuccessModal() {
    document.getElementById('success-modal').style.display = 'block';
}

function closeSuccessModal() {
    document.getElementById('success-modal').style.display = 'none';
    // Redirect to main.html after closing the modal
    window.location.href = 'main.html';
}

// Function to redirect to main.html (can be called from other places if needed)
function redirectToMain() {
    window.location.href = 'main.html';
}

// Close modal when clicking outside and redirect
document.addEventListener('click', function(e) {
    const modal = document.getElementById('success-modal');
    if (e.target === modal) {
        closeSuccessModal(); // This will also redirect
    }
});

// Optional: Add keyboard support for closing modal with Enter or Escape
document.addEventListener('keydown', function(e) {
    const modal = document.getElementById('success-modal');
    if (modal.style.display === 'block') {
        if (e.key === 'Enter' || e.key === 'Escape') {
            closeSuccessModal(); // This will also redirect
        }
    }
});

// Form validation enhancement
document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('input[required], select[required]');
    
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.style.borderColor = 'red';
                this.style.boxShadow = '0 0 5px rgba(255, 0, 0, 0.5)';
            } else {
                this.style.borderColor = '';
                this.style.boxShadow = '';
            }
        });
        
        input.addEventListener('input', function() {
            if (this.value) {
                this.style.borderColor = '';
                this.style.boxShadow = '';
            }
        });
    });
});

// Auto-capitalize functionality for enrollment form
document.addEventListener('DOMContentLoaded', function() {
    // Get all text input fields that should be capitalized (excluding email)
    const fieldsToCapitalize = [
        'first-name',    // First Name
        'last-name',     // Last Name  
        'middle-name'    // Middle Name
    ];

    // Add event listeners to each field for real-time capitalization
    fieldsToCapitalize.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        
        if (field) {
            // Add input event listener for real-time capitalization
            field.addEventListener('input', function(e) {
                const cursorPosition = e.target.selectionStart;
                const capitalizedValue = e.target.value.toUpperCase();
                e.target.value = capitalizedValue;
                
                // Restore cursor position after capitalization
                e.target.setSelectionRange(cursorPosition, cursorPosition);
            });
            
            // Also capitalize on paste events
            field.addEventListener('paste', function(e) {
                setTimeout(() => {
                    const cursorPosition = e.target.selectionStart;
                    const capitalizedValue = e.target.value.toUpperCase();
                    e.target.value = capitalizedValue;
                    e.target.setSelectionRange(cursorPosition, cursorPosition);
                }, 10);
            });
        }
    });
});