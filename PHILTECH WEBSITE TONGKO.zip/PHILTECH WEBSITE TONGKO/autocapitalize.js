// Auto-capitalize functionality for enrollment form
document.addEventListener('DOMContentLoaded', function() {
    // Get all text input fields that should be capitalized (excluding email)
    const fieldsToCapitalize = [
        'first-name',    // First Name
        'last-name',     // Last Name  
        'middle-name'    // Middle Name
    ];

    // Add event listeners to each field for real-time capitalization
    fieldsToCapitalize.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        
        if (field) {
            // Add input event listener for real-time capitalization
            field.addEventListener('input', function(e) {
                const cursorPosition = e.target.selectionStart;
                const capitalizedValue = e.target.value.toUpperCase();
                e.target.value = capitalizedValue;
                
                // Restore cursor position after capitalization
                e.target.setSelectionRange(cursorPosition, cursorPosition);
            });
            
            // Also capitalize on paste events
            field.addEventListener('paste', function(e) {
                setTimeout(() => {
                    const cursorPosition = e.target.selectionStart;
                    const capitalizedValue = e.target.value.toUpperCase();
                    e.target.value = capitalizedValue;
                    e.target.setSelectionRange(cursorPosition, cursorPosition);
                }, 10);
            });
        }
    });
    
    console.log('Auto-capitalize functionality loaded for:', fieldsToCapitalize);
});