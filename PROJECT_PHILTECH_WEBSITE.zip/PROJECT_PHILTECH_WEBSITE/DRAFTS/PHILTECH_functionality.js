

// function to use value of user input to log in form
const loginform = document.querySelector("form");

form.addEventListener("submit",(event)=>{
    event.preventDefault();

    const username = form.username.value;
    const password = form.password.value;

    const authenticated = authentication(username,password);

    if(authenticated){
        window.location.href = "DashboardHome.html";
    }else{
       
    }
});

// function for checking username and password
function authentication(username,password){
    if(username === username && password === password ){
        return true;
    }else{
        return false;
    }
};

// function for sign up button
const signup = document.getElementById('signup');

signup.addEventListener("click",(event)=>{
    window.location.href = "Signup.html";
});

// function to check for user input in log in
var username = document.forms['form']['username'];
var password = document.forms['form']['password'];

var username_error = document.getElementById('username_error');
var password_error = document.getElementById('password_error');

function validated(){
    if(username.value.length == 0) {
        username_error.style.display = "block";
        username.focus();
        return false;
    }
    if(password.value.length == 0) {
        password_error.style.display = "block";
        password.focus();
        return false;
    }
};