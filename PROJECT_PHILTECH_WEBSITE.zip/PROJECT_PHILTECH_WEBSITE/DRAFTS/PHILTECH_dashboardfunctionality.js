//funtion to toggle sidebar
const sidebar = document.querySelector(".sidebar");
const togglesidebar = document.querySelector(".togglesidebar");

togglesidebar.addEventListener("click",function(event){
    sidebar.classList.toggle("expand");
});

// Function to display the current logged-in username
function displayUsername() {
    const usernameElement = document.querySelector(".username");
    // Get the stored username from localStorage
    const currentUsername = localStorage.getItem("currentUser");
    
    if (currentUsername) {
        usernameElement.textContent = `Welcome! ${currentUsername}`;
    } else {
        // If no username is found, redirect to login page
        window.location.href = "PHILTECH_account.html";
    }
}

//function to log out
const logout = document.querySelector(".logout");

logout.addEventListener("click",function(event){
    // Clear the stored username when logging out
    localStorage.removeItem("currentUser");
    window.location.href = "PHILTECH_account.html";
});

// image slider
const slides = document.querySelectorAll(".slides img");
const slideTexts = document.querySelectorAll(".slide-text");
let slideIndex = 0;

document.addEventListener("DOMContentLoaded", function() {
    // Display username when page loads
    displayUsername();
    initializeSlider();
});

function initializeSlider(){
    slides[slideIndex].classList.add("displaySlide");
    slideTexts[slideIndex].classList.add("active-text");
}

function showslide(index){
    if(index >= slides.length ){
        slideIndex = 0;
    }
    else if(index < 0){
        slideIndex = slides.length - 1;
    }

    // function to show and hide images using add and remove classlist property
    slides.forEach(slide => {
        slide.classList.remove("displaySlide");
    });

    slideTexts.forEach(text => {
        text.classList.remove("active-text");
    });
    
    slides[slideIndex].classList.add("displaySlide");
    slideTexts[slideIndex].classList.add("active-text");
}

// function to next image slide
function prevslide(){
    slideIndex--;
    showslide(slideIndex);
}

// function to previous image slide
function nextslide(){
    slideIndex++;
    showslide(slideIndex);
}