// User data storage in localStorage
let users = JSON.parse(localStorage.getItem('users')) || [];

// Function to switch between forms and handle positioning
function showform(formId) {
    document.querySelectorAll(".maincontainer").forEach(form => form.classList.remove("active"));
    document.getElementById(formId).classList.add("active");
}

// Function to center the container for signup
function movecontainer() {
    document.body.style.justifyContent = "center";
    
    // If switching back to login, restore original position
    document.querySelector(".loginlabel a").addEventListener("click", function() {
        document.body.style.justifyContent = "flex-end";
    });
}

// Function to handle sign up
function handleSignUp(event) {
    event.preventDefault();
    
    // Reset error messages
    document.getElementById('newusername_error').style.display = "none";
    document.getElementById('newpassword_error').style.display = "none";
    document.getElementById('username_exists_error').style.display = "none";
    document.getElementById('signup_success').style.display = "none";
    
    const username = document.querySelector('.textboxnewuser').value.trim();
    const password = document.querySelector('.textboxnewpass').value.trim();
    
    // Validation
    let isValid = true;
    
    if (!username) {
        document.getElementById('newusername_error').style.display = "block";
        document.querySelector('.textboxnewuser').focus();
        isValid = false;
    }
    
    if (!password) {
        document.getElementById('newpassword_error').style.display = "block";
        if (isValid) {
            document.querySelector('.textboxnewpass').focus();
        }
        isValid = false;
    }
    
    // Check if username already exists
    if (isValid && users.some(user => user.username === username)) {
        document.getElementById('username_exists_error').style.display = "block";
        document.querySelector('.textboxnewuser').focus();
        isValid = false;
    }
    
    if (!isValid) {
        return;
    }
    
    // Add new user
    users.push({
        username: username,
        password: password
    });
    
    // Save to localStorage
    localStorage.setItem('users', JSON.stringify(users));
    
    // Success message
    document.getElementById('signup_success').style.display = "block";
    setTimeout(() => {
        document.getElementById('signup_success').style.display = "none";
        
        // Clear form and switch to login
        document.querySelector('.textboxnewuser').value = '';
        document.querySelector('.textboxnewpass').value = '';
        showform('login');
        document.body.style.justifyContent = "flex-end"; // Reset position for login form
    }, 2000);
}

// Function to handle login
function handleLogin(event) {
    event.preventDefault();
    
    // Reset error messages
    document.getElementById('username_error').style.display = "none";
    document.getElementById('password_error').style.display = "none";
    
    const username = document.querySelector('.textboxuser').value.trim();
    const password = document.querySelector('.textboxpass').value.trim();
    
    // Validation
    let isValid = true;
    
    if (!username) {
        document.getElementById('username_error').style.display = "block";
        document.querySelector('.textboxuser').focus();
        isValid = false;
    }
    
    if (!password) {
        document.getElementById('password_error').style.display = "block";
        if (isValid) {
            document.querySelector('.textboxpass').focus();
        }
        isValid = false;
    }
    
    if (!isValid) {
        return;
    }
    
    // Check credentials
    const user = users.find(user => user.username === username && user.password === password);
    
    if (user) {
        // Set current user
        localStorage.setItem('currentUser', username);
        
        // Redirect to dashboard
        window.location.href = 'PHILTECH_MainDashboard.html';
    } else {
        // Add invalid credentials error
        // Since this wasn't in the HTML, we'll create it dynamically
        let invalidCredentials = document.getElementById('invalid_credentials_error');
        if (!invalidCredentials) {
            invalidCredentials = document.createElement('div');
            invalidCredentials.id = 'invalid_credentials_error';
            invalidCredentials.innerText = 'Invalid username or password';
            invalidCredentials.style.display = 'block';
            invalidCredentials.style.position = 'absolute';
            invalidCredentials.style.textAlign = 'center';
            invalidCredentials.style.top = '50vh';
            invalidCredentials.style.left = '24vh';
            invalidCredentials.style.borderRadius = '1vh';
            invalidCredentials.style.padding = '0.5vh';
            invalidCredentials.style.border = '1px solid #FFBB00';
            invalidCredentials.style.backgroundColor = '#6B0404';
            invalidCredentials.style.color = '#FFFFFF';
            
            document.querySelector('#login').appendChild(invalidCredentials);
        } else {
            invalidCredentials.style.display = 'block';
        }
    }
}

// Add event listeners after DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add event listener for signup form
    const signupForm = document.querySelector('#signup .forms');
    signupForm.addEventListener('submit', handleSignUp);
    
    // Add event listener for login form
    const loginForm = document.querySelector('#login .forms');
    loginForm.addEventListener('submit', handleLogin);
    
    // Clear error messages when typing
    document.querySelector('.textboxuser').addEventListener('input', function() {
        document.getElementById('username_error').style.display = "none";
        const invalidCredentials = document.getElementById('invalid_credentials_error');
        if (invalidCredentials) {
            invalidCredentials.style.display = "none";
        }
    });
    
    document.querySelector('.textboxpass').addEventListener('input', function() {
        document.getElementById('password_error').style.display = "none";
        const invalidCredentials = document.getElementById('invalid_credentials_error');
        if (invalidCredentials) {
            invalidCredentials.style.display = "none";
        }
    });
    
    document.querySelector('.textboxnewuser').addEventListener('input', function() {
        document.getElementById('newusername_error').style.display = "none";
        document.getElementById('username_exists_error').style.display = "none";
    });
    
    document.querySelector('.textboxnewpass').addEventListener('input', function() {
        document.getElementById('newpassword_error').style.display = "none";
    });
});